
import { BlogsData } from "./BlogsData";
import { ProjectsData } from "./ProjectsData";

export { BlogsData, ProjectsData }
export const ProjectsData = [
    {
        projectName: "IP_lookup",
        route: "/app/iplookup", 
        githubUrl: "",
        projectImage: {
            imageUrl: "/images/developer.png"
        },
        techs: []
    },
    {
        projectName: "City",
        route: "/app/city", 
        githubUrl: "",
        projectImage: {
            imageUrl: "/images/ecommerce.png"
        },
        techs: []
    }
]
export const BlogsData = [
 
  {
    name: "useEffect in React",
    imageUrl:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSbhezzFR6qB93F9NaClSY5oCFZ1wg4j0YQww&usqp=CAU",
    linkName: "react/useEffect",
    date: "July 4, 2023",
  },
  {
    name: "useState in React",
    imageUrl:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRYTiTHUjDbI_QrgGMU6NWTtrjV161GoAzxUQ&usqp=CAU",
    linkName: "react/useState",
    date: "July 5, 2023",
  },
  {
    name: "Virtual DOM in React",
    imageUrl:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRQYGau3eAtYMcIqqrHk2U1CR39SCnyhywjHA&usqp=CAU",
    linkName: "react/virtual-dom",
    date: "July 6, 2023",
  },
  {
    name: "Fragment In React",
    imageUrl:
      "https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcT77S6c9Tlz-zqWRRPgKeJDd8kSjbR_alp30g&usqp=CAU",
    linkName: "react/fragment",
    date: "July 7, 2023",
  },
];

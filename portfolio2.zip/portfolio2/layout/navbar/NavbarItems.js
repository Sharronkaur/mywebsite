export const NavbarMenu = [
    {
        name: "Home",
        link: "#home",
    },
    {
        name: "About",
        link: "#about",
    },
    {
        name: "Blogs",
        link: "#blogs",
    },
    {
        name: "Project",
        link: "#project"
    },
    {
        name: "Contact",
        link:"#contact",
    }
];